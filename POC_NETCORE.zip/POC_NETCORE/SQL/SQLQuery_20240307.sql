


use poc_api_Db


select *from  TBL_TaskDetails

select *from  TBL_SystemConfigDtl 

--(insert ,update ,select)
--TaskAssignment Controller
--insert,update,Select with Taskid

select * from Maintenance_MajorEquipment    where 


Create Table TBL_TaskDetails(TaskID int PRIMARY KEY not null,Title nvarchar(100),Revision nvarchar(5),
Asset_Type nvarchar(50),Manufacturer nvarchar(100) ,Model Nvarchar(100),System_name Nvarchar(50),Asset_number nvarchar(20),CreateBy nvarchar(10) not null,CreatedDt Datetime not null )

--insert into TBL_TaskDetails values ('1','ABC1','A','A-FRAME','ABCD','Model','SYSTEM NAME','12345678','JD',GETDATE())

--drop table TBL_SystemConfigDtl
Create Table TBL_SystemConfigDtl(ID int Primary Key not null,TaskID int not null ,System_name nvarchar(50) not null,
Asset_type nvarchaR(50),Asset_number nvarchar(20),CreateBy nvarchar(10) not null,CreatedDT Datetime not null )

--insert into TBL_SystemConfigDtl values(2,1,'ABCD2','A-Frame','145466789','JD',GETDATE())
--insert into TBL_SystemConfigDtl values(3,2,'mANU','APU','12345678','JD',GETDATE())
--insert into TBL_SystemConfigDtl values(4,2,'mANU2','APU','99945678','JD',GETDATE())

select * from TBL_TaskDetails
select * from TBL_SystemConfigDtl

select * from TBL_SystemConfigDtl

--Create Table TBLMaintenanance_plan(ID int primary key,TASKID int,PlanDT datetime, PlanBy nvarchar(10) ,CreateBy nvarchar(10) not null,CreatedDT Datetime not null )

select * from TBLMaintenanance_plan

--insert into TBLMaintenanance_plan values(1,1,'2024-03-01','Gopal','JD','2024-03-05')
--insert into TBLMaintenanance_plan values(2,1,'2024-03-02','Jagdish','JD','2024-03-06')

--alter table TBL_TaskDetails add primary key (TaskID)

--insert into TBL_TaskDetails values ('1','ABC1','A','A-FRAME','ABCD','Model','SYSTEM NAME','12345678','JD',GETDATE())
