

use POC_API_DB




Create Table TBL_TaskDetails(TaskID int PRIMARY KEY not null,Title nvarchar(100),Revision nvarchar(5),
Asset_Type nvarchar(50),Manufacturer nvarchar(100) ,Model Nvarchar(100),System_name Nvarchar(50),Asset_number nvarchar(20),CreateBy nvarchar(10) not null,CreatedDt Datetime not null )



Create Table TBL_SystemConfigDtl(ID int identity(1,1) not null,System_name nvarchar(50) not null,Asset_type nvarchaR(50),Asset_number nvarchar(20)
,CreateBy nvarchar(10) not null,CreatedDT Datetime not null )


Create table TBL_MaintenancePlan(MplanID int identity(1,1) not null, Asset_type nvarchar(50),Asset_number nvarchar(50),TaksID int,TaksRevision nvarchar(5)
,CreateBy nvarchar(10) not null,CreatedDT Datetime not null)


select * from INFORMATION_SCHEMA.TABLES where TABLE_NAME like '%System%'


