﻿using POC_API.Models;
using POC_API.Repositories.TaskMMPlan;

namespace POC_API.Services.TaskMMPlan
{
    public class TaskMMPlanService : ITaskMMPlanService
    {
        ITaskMMPlanRepository _taskMMPlanRepository;
        public TaskMMPlanService(ITaskMMPlanRepository taskMMPlanRepository)
        {
            _taskMMPlanRepository = taskMMPlanRepository;
        }

        public List<TblmaintenanancePlan> GetAllMMPlan()
        {
            return _taskMMPlanRepository.GetAllMMPlan();
        }

        public async Task<bool> SaveMMPlanAsync(TblmaintenanancePlan tblmaintenanancePlan)
        {
            return await _taskMMPlanRepository.SaveMMPlanAsync(tblmaintenanancePlan);
        }

        public async Task<bool> UpdateTaskMMPlanAsync(TblmaintenanancePlan tblmaintenanancePlan)
        {
            return await _taskMMPlanRepository.UpdateTaskMMPlanASync(tblmaintenanancePlan);
        }



    }
}
