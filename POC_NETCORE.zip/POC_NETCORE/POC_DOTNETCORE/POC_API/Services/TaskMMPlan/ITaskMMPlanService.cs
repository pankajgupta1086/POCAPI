﻿using POC_API.Models;

namespace POC_API.Services.TaskMMPlan
{
    public interface ITaskMMPlanService
    {
         List<TblmaintenanancePlan> GetAllMMPlan();

         Task<bool> SaveMMPlanAsync(TblmaintenanancePlan tblmaintenanancePlan);

        Task<bool> UpdateTaskMMPlanAsync(TblmaintenanancePlan tblmaintenanancePlan);
    }
}
