﻿using POC_API.Models;
using POC_API.Repositories;

namespace POC_API.Services
{
    public class TaskService : ITaskService
    {
        ITaskRepository _taskRepository;

        public TaskService(ITaskRepository taskRepository)
        {
            _taskRepository = taskRepository;
        }

        public async Task<bool> SaveTaskAsync(TblTaskDetail tblTaskDetail)
        {
            return await _taskRepository.SaveTaskAsync(tblTaskDetail);
        }

        public async Task<List<TblTaskDetail>> GetAllTasks()
        {
            return await _taskRepository.GetAllTasksASync();
        }

        public async Task<bool> UpdateTaskAsync(TblTaskDetail tblTaskDetail)
        {
            return await _taskRepository.UpdateTaskASync(tblTaskDetail);
        }
    }
}
