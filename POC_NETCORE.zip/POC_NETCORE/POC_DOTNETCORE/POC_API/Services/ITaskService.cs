﻿using POC_API.Models;

namespace POC_API.Services

{
    public interface ITaskService
    {
        Task<bool> SaveTaskAsync(TblTaskDetail tblTaskDetail);
        Task<List<TblTaskDetail>> GetAllTasks();
        Task<bool> UpdateTaskAsync(TblTaskDetail tblTaskDetail);
    }
}
