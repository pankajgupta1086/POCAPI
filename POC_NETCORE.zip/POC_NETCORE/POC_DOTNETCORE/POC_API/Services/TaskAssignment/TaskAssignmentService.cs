﻿using Microsoft.AspNetCore.Mvc;
using POC_API.Models;
using POC_API.Repositories.TaskAssignment;

namespace POC_API.Services.TaskAssignment
{
    public class TaskAssignmentService : ITaskAssignmentService
    {
        ITaskAssignmentRepository _taskAssignmentRepository;

        public TaskAssignmentService(ITaskAssignmentRepository taskAssignmentRepository)
        {
            _taskAssignmentRepository = taskAssignmentRepository;
        }

        public List<TblSystemConfigDtl> GetAllAssignment()
        {
            return _taskAssignmentRepository.GetAllAssignment();
        }

        public async Task<bool> SaveTaskAsync(TblSystemConfigDtl tblSystemConfigDtl)
        {
            return await _taskAssignmentRepository.SaveTaskAsync(tblSystemConfigDtl);
        }


        public async Task<IActionResult> UpdateTaskAssignmentASync(TblSystemConfigDtl tblSystemConfigDtl)
        {
            return await _taskAssignmentRepository.UpdateTaskAssignmentAsync(tblSystemConfigDtl);
        }
    }
}
