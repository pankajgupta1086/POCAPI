﻿using Microsoft.AspNetCore.Mvc;
using POC_API.Models;

namespace POC_API.Services.TaskAssignment
{
    public interface ITaskAssignmentService
    {
        public List<TblSystemConfigDtl> GetAllAssignment();

        public Task<bool> SaveTaskAsync(TblSystemConfigDtl tblSystemConfigDtl);

        public Task<IActionResult> UpdateTaskAssignmentASync(TblSystemConfigDtl tblSystemConfigDtl);



    }
}
