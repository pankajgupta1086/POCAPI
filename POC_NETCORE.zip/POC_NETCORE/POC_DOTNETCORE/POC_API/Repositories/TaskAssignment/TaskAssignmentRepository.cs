﻿using Microsoft.AspNetCore.Mvc;
using POC_API.Models;

namespace POC_API.Repositories.TaskAssignment
{
    public class TaskAssignmentRepository : ITaskAssignmentRepository
    {
        poc_Context dbContext;

        public TaskAssignmentRepository(poc_Context dbContext)
        {
            this.dbContext = dbContext;
        }

        public List<TblSystemConfigDtl> GetAllAssignment()
        {
            try
            {
                var lst = dbContext.TblSystemConfigDtls.ToList();

                return lst;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public async Task<bool> SaveTaskAsync(TblSystemConfigDtl tblSystemConfigDtl)
        {
            try
            {

                dbContext.TblSystemConfigDtls.Add(tblSystemConfigDtl);

                dbContext.SaveChanges();

                await Task.CompletedTask;

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public async Task<IActionResult> UpdateTaskAssignmentAsync(TblSystemConfigDtl tblSystemConfigDtl)
        {
            try
            {
                var SysConfigdetl = await dbContext.TblSystemConfigDtls.FindAsync(tblSystemConfigDtl.Id);
                if (SysConfigdetl == null)
                    return new BadRequestObjectResult("Not Found");

                SysConfigdetl.TaskId = tblSystemConfigDtl.TaskId;
                SysConfigdetl.SystemName = tblSystemConfigDtl.SystemName;
                SysConfigdetl.AssetNumber = tblSystemConfigDtl.AssetNumber;
                SysConfigdetl.AssetType = tblSystemConfigDtl.AssetType;

                await dbContext.SaveChangesAsync();
 
                await Task.CompletedTask;

                return new OkObjectResult("OK");
            }
            catch (Exception)
            {
                return new  BadRequestObjectResult("Error Occurs");
            }
        }

    }
}
