﻿using Microsoft.AspNetCore.Mvc;
using POC_API.Models;

namespace POC_API.Repositories.TaskAssignment
{
    public interface ITaskAssignmentRepository
    {
         List<TblSystemConfigDtl> GetAllAssignment();

        Task<bool> SaveTaskAsync(TblSystemConfigDtl tblSystemConfigDtl);

        Task<IActionResult> UpdateTaskAssignmentAsync(TblSystemConfigDtl tblSystemConfigDtl);


    }
}
