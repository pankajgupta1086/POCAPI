﻿using POC_API.Models;

namespace POC_API.Repositories.TaskMMPlan
{
    public interface ITaskMMPlanRepository
    {
        public List<TblmaintenanancePlan> GetAllMMPlan();
        public Task<bool> SaveMMPlanAsync(TblmaintenanancePlan tblmaintenanancePlan);

        Task<bool> UpdateTaskMMPlanASync(TblmaintenanancePlan tblmaintenanancePlan);

    }
}
