﻿using POC_API.Models;

namespace POC_API.Repositories.TaskMMPlan
{
    public class TaskMMPlanRepository : ITaskMMPlanRepository
    {
        poc_Context dbContext;

        public TaskMMPlanRepository(poc_Context dbContext)
        {
            this.dbContext = dbContext;
        }

        public List<TblmaintenanancePlan> GetAllMMPlan()
        {
            try
            {
                var lst = dbContext.TblmaintenanancePlans.ToList();

                //   await Task.CompletedTask;
                return lst;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public async Task<bool> SaveMMPlanAsync(TblmaintenanancePlan tblmaintenanance)
        {
            try
            {

                dbContext.TblmaintenanancePlans.Add(tblmaintenanance);

                dbContext.SaveChanges();

                await Task.CompletedTask;

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public async Task<bool> UpdateTaskMMPlanASync(TblmaintenanancePlan tblmaintenanancePlan)
        {
            try
            {

                var taskMMPlan = dbContext.TblmaintenanancePlans.Where(t => t.Id == tblmaintenanancePlan.Id).FirstOrDefault();

                if (taskMMPlan != null)
                {
                    taskMMPlan.PlanBy = tblmaintenanancePlan.PlanBy;
                    taskMMPlan.PlanDt = tblmaintenanancePlan.PlanDt;
                    taskMMPlan.Taskid = tblmaintenanancePlan.Taskid;

                    dbContext.SaveChanges();

                    return true;
                }

                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}
