﻿using Microsoft.EntityFrameworkCore;
using POC_API.Models;

namespace POC_API.Repositories
{
    public class TaskRepository : ITaskRepository
    {
        poc_Context dbContext;

        public TaskRepository(poc_Context dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<bool> SaveTaskAsync(TblTaskDetail tblTaskDetail)
        {
            try
            {

                dbContext.TblTaskDetails.Add(tblTaskDetail);

                dbContext.SaveChanges();

                await Task.CompletedTask;

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public async Task<bool> UpdateTaskASync(TblTaskDetail tblTaskDetail)
        {
            try
            {

                var task = await dbContext.TblTaskDetails.Where(t => t.TaskId == tblTaskDetail.TaskId).FirstOrDefaultAsync();

                if (task != null)
                {
                    task.AssetNumber = tblTaskDetail.AssetNumber;
                    task.SystemName = tblTaskDetail.SystemName;
                    task.CreateBy = tblTaskDetail.CreateBy;

                    dbContext.SaveChanges();

                    return true;
                }

                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public async Task<List<TblTaskDetail>> GetAllTasksASync()
        {
            return await dbContext.TblTaskDetails.ToListAsync();
        }
    }
}
