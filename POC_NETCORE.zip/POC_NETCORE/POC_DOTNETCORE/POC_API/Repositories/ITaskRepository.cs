﻿using POC_API.Models;

namespace POC_API.Repositories
{
    public interface ITaskRepository
    {
        Task<bool> SaveTaskAsync(TblTaskDetail tblTaskDetail);
        Task<List<TblTaskDetail>> GetAllTasksASync();
        Task<bool> UpdateTaskASync(TblTaskDetail tblTaskDetail);
    }
}
