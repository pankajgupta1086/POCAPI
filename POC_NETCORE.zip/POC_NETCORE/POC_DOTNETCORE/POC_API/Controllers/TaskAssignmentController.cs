﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using POC_API.Models;
using POC_API.Services.TaskAssignment;

namespace POC_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskAssignmentController : ControllerBase
    {
        private readonly ITaskAssignmentService _taskAssignmentService;


        public TaskAssignmentController(ITaskAssignmentService taskAssignmentservice)
        { 
        _taskAssignmentService = taskAssignmentservice;
        }

        [HttpGet]
        public List<TblSystemConfigDtl> GetAllAssignment()
        {
            var lst = _taskAssignmentService.GetAllAssignment();

            return lst;
        }

        [HttpPost]
        public async Task<IActionResult> TaskAssignmentDetl([FromBody] TblSystemConfigDtl tblSystemConfigDtl)
        {

            bool result = await _taskAssignmentService.SaveTaskAsync(tblSystemConfigDtl);

            if (!result)
            {
                return new BadRequestObjectResult("NOT OK");

            }
            return new OkObjectResult("OK");


        }

        [HttpPut]
        public async Task<IActionResult> UpdateTaskAssignementAsync(TblSystemConfigDtl tblSystemConfigDtl)
        {
            return await _taskAssignmentService.UpdateTaskAssignmentASync(tblSystemConfigDtl);
        }

    }
}
