﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using POC_API.Models;
using POC_API.Services.TaskMMPlan;

namespace POC_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskMMPlanController : ControllerBase
    {
        private readonly ITaskMMPlanService _taskMMPlanService;

        public TaskMMPlanController(ITaskMMPlanService taskMMPlanService)
        {
            _taskMMPlanService = taskMMPlanService;
        }


        [HttpGet]
        public List<TblmaintenanancePlan> GetAllMMPlan()
        {

            var result = _taskMMPlanService.GetAllMMPlan();

            return result;

        }

        [HttpPost]
        public async Task<IActionResult> SavePlanDetl([FromBody] TblmaintenanancePlan tblmaintenanancePlan)
        {

            bool result = await _taskMMPlanService.SaveMMPlanAsync(tblmaintenanancePlan);

            if (!result)
            {
                return new BadRequestObjectResult("NOT OK");

            }
            return new OkObjectResult("OK");


        }


        [HttpPut]
        public async Task<bool> UpdateTaskMMPlanAsync(TblmaintenanancePlan tblmaintenanancePlan)
        {
            return await _taskMMPlanService.UpdateTaskMMPlanAsync(tblmaintenanancePlan);
        }


    }



}
