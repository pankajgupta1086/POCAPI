﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using POC_API.Models;
using POC_API.Services;

namespace POC_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {

        private readonly ITaskService _taskService;

        public TaskController(ITaskService taskService)
        {
            _taskService = taskService;
        }

        [HttpPost]
        public async Task<IActionResult> TaskDetl([FromBody] TblTaskDetail tblTaskDetail)
        {

            bool result = await _taskService.SaveTaskAsync(tblTaskDetail);

            if (!result)
            {
                return new BadRequestObjectResult("NOT OK");

            }
            return new OkObjectResult("OK");


        }


        [HttpGet]
        public async Task<IActionResult> GetAllTasks()
        {
            var result = await _taskService.GetAllTasks();

            return new OkObjectResult(result);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateTask([FromBody] TblTaskDetail tblTaskDetail)
        {
            var result = await _taskService.UpdateTaskAsync(tblTaskDetail);

            return new OkObjectResult(result);
        }
    }
}
