﻿using System;
using System.Collections.Generic;

namespace POC_API.Models
{
    public partial class TblmaintenanancePlan
    {
        public int Id { get; set; }
        public int? Taskid { get; set; }
        public DateTime? PlanDt { get; set; }
        public string? PlanBy { get; set; }
        public string CreateBy { get; set; } = null!;
        public DateTime CreatedDt { get; set; }
    }
}
