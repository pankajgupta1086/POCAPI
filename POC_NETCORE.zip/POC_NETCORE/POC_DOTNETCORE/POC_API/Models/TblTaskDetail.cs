﻿using System;
using System.Collections.Generic;

namespace POC_API.Models
{
    public partial class TblTaskDetail
    {
        public int TaskId { get; set; }
        public string? Title { get; set; }
        public string? Revision { get; set; }
        public string? AssetType { get; set; }
        public string? Manufacturer { get; set; }
        public string? Model { get; set; }
        public string? SystemName { get; set; }
        public string? AssetNumber { get; set; }
        public string CreateBy { get; set; } = null!;
        public DateTime CreatedDt { get; set; }
    }
}
