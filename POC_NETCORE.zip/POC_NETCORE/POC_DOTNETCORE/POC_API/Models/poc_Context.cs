﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace POC_API.Models
{
    public partial class poc_Context : DbContext
    {
        public poc_Context()
        {
        }

        public poc_Context(DbContextOptions<poc_Context> options)
            : base(options)
        {
        }

        public virtual DbSet<TblSystemConfigDtl> TblSystemConfigDtls { get; set; } = null!;
        public virtual DbSet<TblTaskDetail> TblTaskDetails { get; set; } = null!;
        public virtual DbSet<TblmaintenanancePlan> TblmaintenanancePlans { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=JAGDISHD\\SQLEXPRESS;Database=poc_API;Trusted_Connection=True;Integrated Security=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TblSystemConfigDtl>(entity =>
            {
                entity.ToTable("TBL_SystemConfigDtl");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("ID");

                entity.Property(e => e.AssetNumber)
                    .HasMaxLength(20)
                    .HasColumnName("Asset_number");

                entity.Property(e => e.AssetType)
                    .HasMaxLength(50)
                    .HasColumnName("Asset_type");

                entity.Property(e => e.CreateBy).HasMaxLength(10);

                entity.Property(e => e.CreatedDt)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedDT");

                entity.Property(e => e.SystemName)
                    .HasMaxLength(50)
                    .HasColumnName("System_name");

                entity.Property(e => e.TaskId).HasColumnName("TaskID");
            });

            modelBuilder.Entity<TblTaskDetail>(entity =>
            {
                entity.HasKey(e => e.TaskId)
                    .HasName("PK__TBL_Task__7C6949D13D1C370E");

                entity.ToTable("TBL_TaskDetails");

                entity.Property(e => e.TaskId)
                    .ValueGeneratedNever()
                    .HasColumnName("TaskID");

                entity.Property(e => e.AssetNumber)
                    .HasMaxLength(20)
                    .HasColumnName("Asset_number");

                entity.Property(e => e.AssetType)
                    .HasMaxLength(50)
                    .HasColumnName("Asset_Type");

                entity.Property(e => e.CreateBy).HasMaxLength(10);

                entity.Property(e => e.CreatedDt).HasColumnType("datetime");

                entity.Property(e => e.Manufacturer).HasMaxLength(100);

                entity.Property(e => e.Model).HasMaxLength(100);

                entity.Property(e => e.Revision).HasMaxLength(5);

                entity.Property(e => e.SystemName)
                    .HasMaxLength(50)
                    .HasColumnName("System_name");

                entity.Property(e => e.Title).HasMaxLength(100);
            });

            modelBuilder.Entity<TblmaintenanancePlan>(entity =>
            {
                entity.ToTable("TBLMaintenanance_plan");

                entity.Property(e => e.Id)
                    .ValueGeneratedNever()
                    .HasColumnName("ID");

                entity.Property(e => e.CreateBy).HasMaxLength(10);

                entity.Property(e => e.CreatedDt)
                    .HasColumnType("datetime")
                    .HasColumnName("CreatedDT");

                entity.Property(e => e.PlanBy).HasMaxLength(10);

                entity.Property(e => e.PlanDt)
                    .HasColumnType("datetime")
                    .HasColumnName("PlanDT");

                entity.Property(e => e.Taskid).HasColumnName("TASKID");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
