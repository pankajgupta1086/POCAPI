using Microsoft.EntityFrameworkCore;
using POC_API.Models;
using POC_API.Repositories;
using POC_API.Repositories.TaskAssignment;
using POC_API.Repositories.TaskMMPlan;
using POC_API.Services;
using POC_API.Services.TaskAssignment;
using POC_API.Services.TaskMMPlan;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<poc_Context>(
        options => options.UseSqlServer("Server=JAGDISHD\\SQLEXPRESS;Database=POC_API_DB;Trusted_Connection=True;Integrated Security=True;"));

builder.Services.AddScoped<ITaskService, TaskService>();
builder.Services.AddScoped<ITaskRepository, TaskRepository>();

builder.Services.AddScoped<ITaskAssignmentService, TaskAssignmentService>();
builder.Services.AddScoped<ITaskAssignmentRepository, TaskAssignmentRepository>();

builder.Services.AddScoped<ITaskMMPlanService, TaskMMPlanService>();
builder.Services.AddScoped<ITaskMMPlanRepository, TaskMMPlanRepository>();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
