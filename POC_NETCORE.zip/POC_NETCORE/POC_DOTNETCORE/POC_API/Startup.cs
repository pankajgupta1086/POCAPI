﻿//using  Mic EFGetStarted.AspNetCore.ExistingDb.Models;
using Microsoft.EntityFrameworkCore;
using POC_API.Models;
using POC_API.Services;

namespace POC_API
{
    public class Startup
    {
        public IConfiguration configRoot
        {
            get;
        }
        public Startup(IConfiguration configuration)
        {
            configRoot = configuration;
        }
        public void ConfigureServices(IServiceCollection services)
        {
            
            var connection = @"JAGDISHD\SQLEXPRESS;Database=POC_API_DB;Trusted_Connection=True;Integrated Security=True";

            //            var connection = @"Server=192.168.1.95\sql2014;Initial Catalog=SocietyManagement;User Id=flex;Password=flex";
            services.AddDbContext<poc_Context>(options => options.UseSqlServer(connection));

        services.AddRazorPages();
        }


        public void Configure(WebApplication app, IWebHostEnvironment env)
        {
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();
            app.UseAuthorization();
            app.MapRazorPages();
            app.Run();
        }
    }
}
